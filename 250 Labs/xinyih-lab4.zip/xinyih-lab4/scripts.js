
function showDescription(descript){
	console.log("seen");
	$("#description").html("Description: " + descript);

}

function hideDescription(){
	$("#description").html();
}