function showDescription(descript){
	$("#description").html("Description: " + descript);

}

function hideDescription(){
	$("#description").html();
}